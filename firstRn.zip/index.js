
import Root from './app/root';
import { AppRegistry, } from 'react-native';

AppRegistry.registerComponent('firstRn', () => Root);
